<?php $__env->startSection('title', 'Edit Product'); ?>
<?php $__env->startSection('content'); ?>



    <form class="form-horizontal" method="POST" action="/product/update" enctype="multipart/form-data">
        
        <div class="row">
            <div class="col-12">

                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade in">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong><?php echo e(session('success')); ?>!</strong>
                    </div>
                <?php endif; ?>
                <?php if(session('failed')): ?>
                    <div class="alert alert-danger alert-dismissible fade in">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong><?php echo e(session('failed')); ?>!</strong>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="row">
            <div class="col-9">
                <div class="card-box">

                    <div class="row">
                        <div class="col-12">
                            <div class="p-20">

                                <div class="form-group row">
                                    <label>Product Title</label>
                                    <input type="text" class="form-control" name="productTitle" value="<?php echo e($product->productTitle); ?>">
                                    <input type="hidden" class="form-control" name="productId" value="<?php echo e($product->productId); ?>">
                                    <input type="hidden" class="form-control" name="_token" value="<?php echo e(csrf_token()); ?>">
                                </div>

                                <div class="form-group row">
                                    <label>Product Description</label>
                                    <div class="col-sm-12">
                                        <textarea type="text" class="form-control summernote" name="productDescription" rows="15"><?php echo e($product->productDescription); ?></textarea>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label>Product Title</label>
                                    <input type="text" class="form-control" name="productTitle2" value="<?php echo e($product->productTitle2); ?>">
                                </div>

                                <div class="form-group row">
                                    <label>Product Description</label>
                                    <div class="col-sm-12">
                                        <textarea type="text" class="form-control summernote" name="productDescription2" rows="15"><?php echo e($product->productDescription2); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <!-- end row -->

                </div> <!-- end card-box -->
            </div><!-- end col -->

            <div class="col-3">
                <div class="card-box">
                    <hr>
                    <div class="row">
                        <div class="col-12">
                            <div class="p-20">
                                <div class="form-group row">
                                    <label>Category</label>

                                    <select class="form-control" name="categoryId">
                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cat->categoryId); ?>"><?php echo e($cat->categoryName); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group row">
                                    <label>Product Image</label>

                                    <input type="file" class="form-control" name="image">
                                    <input type="text" class="form-control" value="<?php echo e($product->productImage); ?>" name="image">
                                </div>

                                <div class="form-group row">
                                    <label>Product Image2</label>

                                    <input type="file" class="form-control" name="image2">
                                    <input type="text" class="form-control" value="<?php echo e($product->productImage2); ?>" name="image2">
                                </div>

                                <div class="form-group row">
                                    <label>Product File</label>

                                    <input type="file" class="form-control" name="image3">
                                    <input type="text" class="form-control" value="<?php echo e($product->productFile); ?>" name="image3">
                                </div>
                            </div>
                        </div>

                    </div>
                    <!-- end row -->

                </div> <!-- end card-box -->
            </div><!-- end col -->

        </div>
        <div class="row">
            <div class="col-sm-12">
                <hr>
                <div class="text-center p-20">
                    <button type="submit" class="btn w-sm btn-white waves-effect">Cancel</button>
                    <button type="submit" class="btn w-sm btn-default waves-effect waves-light">Save</button>
                    <button type="submit" class="btn w-sm btn-danger waves-effect waves-light">Delete</button>
                </div>
            </div>
        </div>
    </form>
    <!-- end row -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel-fresh\elevator\resources\views/admin/pages/product/edit.blade.php ENDPATH**/ ?>