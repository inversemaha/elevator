<?php $__env->startSection('title', 'Elevator Engineers'); ?>
<?php $__env->startSection('content'); ?>

    <!-- about us slider -->
    <section id="about-us" class="pading">
        <div class="container">
            <div class="row wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
                <div class="col-md-12 text-center">
                    <h2 class="heading-margin">Our Business Partners</h2>
                    
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12 text-center">
                    <div class="about-text wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
                        <h3>About ELEVATOR ENGINEERS LTD.</h3>
                        <p class="text-justify">Our company is your best source for value-driven elevator and lift systems.
                            Established in 2005, we have over 13 years of collective knowledge and experience that give us a unique advantage in providing professional services to the consumer. We are  able to provide the most value and innovation per Take spent by providing a satisfaction guarantee for every service provided.
                        </p>
                    </div>
                </div>
                
                    
                        
                            
                            
                                
                                
                                
                            
                            
                                
                                
                                
                            
                            
                                
                            
                            
                                
                            
                        
                        
                    
                
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel-fresh\elevator\resources\views/general/our_partner/index.blade.php ENDPATH**/ ?>