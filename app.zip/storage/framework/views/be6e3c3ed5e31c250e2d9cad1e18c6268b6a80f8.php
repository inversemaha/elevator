
<!--/BG-Banner-->
<section style="background:url('<?php echo e(asset('fontEnd/images/page-banner-1.jpg')); ?>') repeat scroll 0 0 / cover" class="page-banner">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h2 class="page-banner-heading wow fadeInLeft animated" style="visibility: visible; animation-name: fadeInLeft">All kinds of Lift, Escalator, AVR, Generator Importer & Supplier
                </h2>
                <div class="bread-crumb wow fadeInRight animated" style="visibility: visible; animation-name: fadeInRight;"> <span class="initial-text"> <a href="/">Home</a></span> </div>
            </div>
        </div>
    </div>
</section>
<!--/#BG-Banner-->

<?php /**PATH D:\laravel-fresh\elevator\resources\views/include/pageSlider.blade.php ENDPATH**/ ?>