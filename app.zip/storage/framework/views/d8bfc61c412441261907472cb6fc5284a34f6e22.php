<?php $__env->startSection('title', 'Show All Features'); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <div class="row">
                    <div class="col-sm-6">
                        <h4>View All Products</h4>

                    </div>
                    <div class="col-sm-6">
                        <a href="/feature/create" class="btn btn-sm btn-primary pull-right"><i
                                    class="md md-add"></i> Add New</a>
                    </div>
                </div>

                <hr>

                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <strong></strong> <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('decline')): ?>
                    <div class="alert alert-danger">
                        <strong></strong> <?php echo e(session('failed')); ?>

                    </div>
                <?php endif; ?>

                <?php if(isset($feature)): ?>
                    <table id="datatable-buttons" class="table table-striped table-bordered" cellspacing="0"
                           width="100%">
                        <thead>
                        <tr>
                            <th>SL</th>
                            <th>Product Name</th>
                            <th>Feature Name</th>
                            
                            <th>Feature Image</th>
                            <th>Feature Title 2</th>
                            
                            <th>Feature Image 2</th>
                            <th>Feature Title 3</th>
                            
                            <th>Feature Image 3</th>
                            <th>Action</th>
                        </tr>
                        </thead>


                        <tbody>
                        <?php ($i=1); ?>
                        <?php $__currentLoopData = $feature; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($fea->productTitle); ?></td>
                                <td><?php echo e($fea->featureTitle); ?></td>
                                
                                <td><img src="/images/feature/<?php echo e($fea->featureImage); ?>" class="img-rounded"
                                         alt="Feature image" width="150" height="80"></td>
                                <td><?php echo e($fea->featureTitle2); ?></td>
                                
                                <td><img src="/images/feature/<?php echo e($fea->featureImage2); ?>" class="img-rounded"
                                         alt="Feature image" width="150" height="80"></td>
                                <td><?php echo e($fea->featureTitle3); ?></td>
                                
                                <td><img src="/images/feature/<?php echo e($fea->featureImage3); ?>" class="img-rounded"
                                         alt="Feature image" width="150" height="80"></td>
                                <td>
                                    <button type="button"
                                            class="btn btn-sm btn-danger dropdown-toggle waves-effect waves-light"
                                            data-toggle="dropdown" aria-expanded="false">Action<span
                                                class="caret"></span></button>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item"
                                           href="/feature/edit/<?php echo e($fea->featureId); ?>"><i
                                                    class="fa fa-edit"></i> Edit</a>
                                        <a class="dropdown-item"
                                           href="/feature/destroy/<?php echo e($fea->featureId); ?>"><i
                                                    class="fa fa-remove"></i> Delete</a>
                                        
                                    </div>
                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>


                <?php endif; ?>
            </div>
            <!-- end row -->


        </div> <!-- end card-box -->
    </div><!-- end col -->
    <!-- end row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel-fresh\elevator\resources\views/admin/pages/feature/show.blade.php ENDPATH**/ ?>