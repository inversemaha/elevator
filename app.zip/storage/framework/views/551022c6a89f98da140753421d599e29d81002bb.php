<?php $__env->startSection('title', 'Show All Services'); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <div class="row">
                    <div class="col-sm-6">
                        <h4>View All Services</h4>

                    </div>
                    <div class="col-sm-6">
                        <a href="/service/create" class="btn btn-sm btn-primary pull-right"><i
                                    class="md md-add"></i> Add New</a>
                    </div>
                </div>

                <hr>

                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <strong></strong> <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('decline')): ?>
                    <div class="alert alert-danger">
                        <strong></strong> <?php echo e(session('failed')); ?>

                    </div>
                <?php endif; ?>

                <?php if(isset($services)): ?>
                    <table id="datatable-buttons" class="table table-striped table-bordered" cellspacing="0"
                           width="100%">
                        <thead>
                        <tr>
                            <th>SL</th>
                            <th>Service Title</th>
                            
                            <th>Service Image</th>
                            <th>Maintenance Title</th>
                            
                            <th>Maintenance Image</th>
                            <th>Consultant Title</th>
                           
                            <th>Consultant Image</th>
                            <th>Action</th>
                        </tr>
                        </thead>


                        <tbody>
                        <?php ($i=1); ?>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($ser->serviceTitle); ?></td>
                                
                                <td><img src="/images/services/<?php echo e($ser->serviceImage); ?>" class="img-rounded"
                                         alt="services image" width="150" height="80"></td>
                                <td><?php echo e($ser->maintenanceTitle); ?></td>
                                
                                <td><img src="/images/services/<?php echo e($ser->maintenanceImage); ?>" class="img-rounded"
                                         alt="services image" width="150" height="80"></td>
                                <td><?php echo e($ser->consultantTitle); ?></td>
                                
                                <td><img src="/images/services/<?php echo e($ser->consultantImage); ?>" class="img-rounded"
                                         alt="services image" width="150" height="80"></td>
                                <td>
                                    <button type="button"
                                            class="btn btn-sm btn-danger dropdown-toggle waves-effect waves-light"
                                            data-toggle="dropdown" aria-expanded="false">Action<span
                                                class="caret"></span></button>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item"
                                           href="/service/edit/<?php echo e($ser->serviceId); ?>"><i
                                                    class="fa fa-edit"></i> Edit</a>
                                        <a class="dropdown-item"
                                           href="/service/destroy/<?php echo e($ser->serviceId); ?>"><i
                                                    class="fa fa-remove"></i> Delete</a>
                                        
                                    </div>
                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>


                <?php endif; ?>
            </div>
            <!-- end row -->


        </div> <!-- end card-box -->
    </div><!-- end col -->
    <!-- end row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel-fresh\elevator\resources\views/admin/pages/service/show.blade.php ENDPATH**/ ?>